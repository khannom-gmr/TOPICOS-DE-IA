#include <stdio.h>
#include <stdlib.h>
#include "grafo.h"
typedef struct NodoCola {
    int valor;
    struct NodoCola* siguiente;
} NodoCola;
typedef struct {
    NodoCola* frente;
    NodoCola* final;
} Cola;
void iniciarCola(Cola* c) {
    c->frente = c->final = NULL;
}
int colaVacia(Cola* c) {
    return c->frente == NULL;
}
void encolar(Cola* c, int valor) {
    NodoCola* nuevo = (NodoCola*)malloc(sizeof(NodoCola));
    nuevo->valor = valor;
    nuevo->siguiente = NULL;

    if (c->final == NULL) {
        c->frente = c->final = nuevo;
        return;
    }
    c->final->siguiente = nuevo;
    c->final = nuevo;
}
int desencolar(Cola* c) {
    if (colaVacia(c)) return -1;

    NodoCola* temp = c->frente;
    int valor = temp->valor;

    c->frente = c->frente->siguiente;
    if (c->frente == NULL)
        c->final = NULL;

    free(temp);
    return valor;
}
void inicializarGrafo(Grafo* g) {
    for (int i = 0; i < MAX_NODOS; i++)
        g->lista[i] = NULL;
}

void agregarArista(Grafo* g, int origen, int destino, int peso) {
    Arista* nueva = (Arista*)malloc(sizeof(Arista));
    nueva->destino = destino;
    nueva->peso = peso;
    nueva->siguiente = g->lista[origen];
    g->lista[origen] = nueva;
}
int buscarEnAnchura(Grafo* g, int origen, int objetivo, int visitado[], int padre[]) {
    Cola cola;
    iniciarCola(&cola);

    encolar(&cola, origen);
    visitado[origen] = 1;

    while (!colaVacia(&cola)) {
        int actual = desencolar(&cola);

        if (actual == objetivo)
            return 1;

        Arista* aux = g->lista[actual];

        while (aux != NULL) {
            if (!visitado[aux->destino]) {
                encolar(&cola, aux->destino);
                visitado[aux->destino] = 1;
                padre[aux->destino] = actual;
            }
            aux = aux->siguiente;
        }
    }

    return 0;
}