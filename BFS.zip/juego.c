#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX 100

typedef struct {
    int x, y;
} Point;

typedef struct Node {
    Point point;
    int g, h, f;
    struct Node* parent;
} Node;
int isValid(int row, int col, int ROW, int COL) {
    return (row >= 0) && (row < ROW) && (col >= 0) && (col < COL);
}

int isUnBlocked(char** grid, int row, int col) {
    return grid[row][col] != '#';
}

int isDestination(int row, int col, Point dest) {
    return row == dest.x && col == dest.y;
}

int calculateHValue(int row, int col, Point dest) {
    return abs(row - dest.x) + abs(col - dest.y);
}

void tracePath(Node* destNode, char** grid) {
    Node* current = destNode;
    while (current->parent != NULL) {
        if (grid[current->point.x][current->point.y] != 'G')
            grid[current->point.x][current->point.y] = '*';
        current = current->parent;
    }
}
void aStarSearch(char** grid, Point start, Point dest, int ROW, int COL) {
    int closedList[ROW][COL];
    Node* allNodes[ROW][COL];

    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            closedList[i][j] = 0;
            allNodes[i][j] = NULL;
        }
    }

    Node* startNode = (Node*)malloc(sizeof(Node));
    startNode->point = start;
    startNode->g = 0;
    startNode->h = calculateHValue(start.x, start.y, dest);
    startNode->f = startNode->g + startNode->h;
    startNode->parent = NULL;
    allNodes[start.x][start.y] = startNode;

    Node* openList[ROW * COL];
    int openListSize = 0;
    openList[openListSize++] = startNode;

    int dx[] = {-1, 0, 1, 0};
    int dy[] = {0, 1, 0, -1};

    while (openListSize > 0) {
        int minIndex = 0;
        for (int i = 1; i < openListSize; i++) {
            if (openList[i]->f < openList[minIndex]->f) {
                minIndex = i;
            }
        }

        Node* currentNode = openList[minIndex];
        for (int i = minIndex; i < openListSize - 1; i++) {
            openList[i] = openList[i + 1];
        }
        openListSize--;

        int x = currentNode->point.x;
        int y = currentNode->point.y;
        closedList[x][y] = 1;

        if (isDestination(x, y, dest)) {
            tracePath(currentNode, grid);
            return;
        }

        for (int i = 0; i < 4; i++) {
            int newX = x + dx[i];
            int newY = y + dy[i];

            if (isValid(newX, newY, ROW, COL) && isUnBlocked(grid, newX, newY) && !closedList[newX][newY]) {
                int gNew = currentNode->g + 1;
                int hNew = calculateHValue(newX, newY, dest);
                int fNew = gNew + hNew;

                if (allNodes[newX][newY] == NULL || allNodes[newX][newY]->f > fNew) {
                    Node* successor = (Node*)malloc(sizeof(Node));
                    successor->point.x = newX;
                    successor->point.y = newY;
                    successor->g = gNew;
                    successor->h = hNew;
                    successor->f = fNew;
                    successor->parent = currentNode;
                    allNodes[newX][newY] = successor;
                    openList[openListSize++] = successor;
                }
            }
        }
    }

    printf("No se encontró un camino.\n");
}
int main() {
    int ROW, COL;
    printf("Ingrese el número de filas y columnas del tablero: ");
    scanf("%d %d", &ROW, &COL);

    // Asignar memoria para la cuadrícula
    char** grid = (char**)malloc(ROW * sizeof(char*));
    for (int i = 0; i < ROW; i++) {
        grid[i] = (char*)malloc(COL * sizeof(char));
        for (int j = 0; j < COL; j++) {
            grid[i][j] = '.';
        }
    }

    int numObstacles;
    printf("Ingrese el número de obstáculos: ");
    scanf("%d", &numObstacles);
    printf("Ingrese las posiciones de los obstáculos (fila y columna):\n");
    for (int i = 0; i < numObstacles; i++) {
        int x, y;
        scanf("%d %d", &x, &y);
        if (x >= 0 && x < ROW && y >= 0 && y < COL) {
            grid[x][y] = '#';
        } else {
            printf("Posición inválida. Intente de nuevo.\n");
            i--;
        }
    }

    Point start, dest;
    printf("Ingrese la posición de inicio (fila y columna): ");
    scanf("%d %d", &start.x, &start.y);
    if (start.x < 0 || start.x >= ROW || start.y < 0 || start.y >= COL || grid[start.x][start.y] == '#') {
        printf("Posición de inicio inválida.\n");
        return 1;
    }
    grid[start.x][start.y] = 'S';

    printf("Ingrese la posición de destino (fila y columna): ");
    scanf("%d %d", &dest.x, &dest.y);
    if (dest.x < 0 || dest.x >= ROW || dest.y < 0 || dest.y >= COL || grid[dest.x][dest.y] == '#') {
        printf("Posición de destino inválida.\n");
        return 1;
    }
    grid[dest.x][dest.y] = 'G';

    aStarSearch(grid, start, dest, ROW, COL);

    printf("Resultado:\n");
    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            printf("%c ", grid[i][j]);
        }
        printf("\n");
    }

    // Liberar memoria
    for (int i = 0; i < ROW; i++) {
        free(grid[i]);
    }
    free(grid);

    return 0;
}
