#ifndef GRAFO_H
#define GRAFO_H

#define MAX_NODOS 100

typedef struct Arista {
    int destino;
    int peso;
    struct Arista* siguiente;
} Arista;

typedef struct {
    Arista* lista[MAX_NODOS];
} Grafo;


void inicializarGrafo(Grafo* g);
void agregarArista(Grafo* g, int origen, int destino, int peso);

int buscarEnAnchura(Grafo* g, int origen, int objetivo, int visitado[], int padre[]);

#endif